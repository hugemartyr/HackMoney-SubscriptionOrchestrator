# mole-and-hole-game

this is a simple mole and hole a web based game built using html css js. <br/>
where you have to catch the mole, whenever you click on mole you will get points.

### Let's chase your friend in the game.
https://dhruv35m.github.io/hole-and-mole-game/
