moles.forEach((mole) => mole.addEventListener("click", handleMoleHit));

// Initialize Yellow SDK on page load
window.addEventListener('load', loadYellowSDK);