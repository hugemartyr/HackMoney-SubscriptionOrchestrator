declare module "@erc7824/nitrolite" {
  const nitrolite: any;
  export default nitrolite;
}
