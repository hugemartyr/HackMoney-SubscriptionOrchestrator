import { NitroliteProtocol, NitroliteConfig } from './nitrolite';

// Example usage (to be extended in real implementation)
const config: NitroliteConfig = {
  rpcUrl: process.env.RPC_URL || 'https://rpc.example.com',
  privateKey: process.env.PRIVATE_KEY || '0x...',
  chainId: parseInt(process.env.CHAIN_ID || '1337', 10),
};

const nitrolite = new NitroliteProtocol(config);

export { NitroliteProtocol, NitroliteConfig };
export default nitrolite;
