import { YellowSDK } from '@yellow.network/sdk';

export interface NitroliteConfig {
  rpcUrl: string;
  privateKey: string;
  chainId: number;
}

export class NitroliteProtocol {
  private sdk: YellowSDK;

  constructor(config: NitroliteConfig) {
    this.sdk = new YellowSDK({
      rpcUrl: config.rpcUrl,
      privateKey: config.privateKey,
      chainId: config.chainId,
    });
  }

  async createChannel(participantA: string, participantB: string, asset: string, amount: string) {
    const channel = await this.sdk.nitrolite.createChannel({
      participants: [participantA, participantB],
      asset,
      amount,
    });
    return channel;
  }

  async updateState(channelId: string, newState: string, signatureA: string, signatureB: string) {
    const update = await this.sdk.nitrolite.updateState({
      channelId,
      newState,
      signatures: [signatureA, signatureB],
    });
    return update;
  }

  async closeChannel(channelId: string, finalState: string, signatureA: string, signatureB: string) {
    const close = await this.sdk.nitrolite.closeChannel({
      channelId,
      finalState,
      signatures: [signatureA, signatureB],
    });
    return close;
  }
}
