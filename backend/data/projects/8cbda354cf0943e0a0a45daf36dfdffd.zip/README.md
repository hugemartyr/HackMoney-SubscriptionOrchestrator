# Flappy Bird Clone

A production-ready Flappy Bird clone built with TypeScript, HTML5 Canvas, and Vite.

## Features

- **Full-screen responsive canvas** that adapts to window resizing
- **HTML overlay** for player name input (accessible and user-friendly)
- **Physics-based bird movement** with gravity and velocity
- **Pipe generation system** with random gaps
- **AABB collision detection** for pipes, ground, and ceiling
- **Scoring system** that tracks passed pipes
- **Clean OOP architecture** with modular classes

## Tech Stack

- **TypeScript** (strict mode)
- **HTML5 Canvas API** (2D context)
- **Vite** (build tool and dev server)
- **Node.js** (runtime environment)

## Project Structure

```
flappybird/
├── src/
│   ├── main.ts           # Entry point
│   ├── Game.ts           # Game loop and state management
│   ├── Bird.ts           # Bird physics and rendering
│   ├── PipeManager.ts    # Pipe generation and management
│   ├── InputHandler.ts   # Input event handling
│   ├── types.ts          # TypeScript interfaces
│   └── constants.ts      # Game constants
├── styles/
│   └── main.css          # Styling
├── index.html            # HTML structure
├── package.json          # Dependencies
├── tsconfig.json         # TypeScript config
└── vite.config.ts        # Vite config
```

## Setup & Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm run dev
   ```

3. **Build for production:**
   ```bash
   npm run build
   ```

4. **Preview production build:**
   ```bash
   npm run preview
   ```

## How to Play

1. Enter your name in the input field
2. Click "Start Game" or press Enter
3. Click the mouse or press Spacebar to make the bird jump
4. Avoid pipes, ground, and ceiling
5. Score points by passing through pipes
6. When game over, click "Play Again" to restart

## Controls

- **Mouse Click**: Make bird jump
- **Spacebar**: Make bird jump
- **Enter**: Start game (when on start screen)

## Game Mechanics

- **Gravity**: Constant downward acceleration
- **Jump**: Instant upward velocity boost
- **Pipes**: Spawn at regular intervals with random gap positions
- **Scoring**: One point per pipe pair passed
- **Collision**: AABB (Axis-Aligned Bounding Box) detection

## Browser Compatibility

Works in all modern browsers that support:
- HTML5 Canvas
- ES2020 JavaScript features
- CSS Flexbox

## License

MIT
