import { GameState } from './types';
import { Bird } from './Bird';
import { PipeManager } from './PipeManager';
import { InputHandler } from './InputHandler';
import { BIRD_START_X, BIRD_START_Y_OFFSET, GROUND_HEIGHT, CEILING_HEIGHT } from './constants';

/**
 * Game - Manages game loop, state, collision detection, and rendering
 */
export class Game {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D;
    private bird: Bird;
    private pipeManager: PipeManager;
    private inputHandler: InputHandler;
    private playerName: string;
    private score: number;
    private state: GameState;
    private lastFrameTime: number;
    private animationFrameId: number | null = null;

    constructor(canvas: HTMLCanvasElement, playerName: string) {
        this.canvas = canvas;
        const context = canvas.getContext('2d');
        if (!context) {
            throw new Error('Failed to get 2D rendering context');
        }
        this.ctx = context;
        this.playerName = playerName;
        this.score = 0;
        this.state = GameState.Playing;
        this.lastFrameTime = performance.now();

        // Initialize bird at starting position
        const birdStartY = canvas.height * BIRD_START_Y_OFFSET;
        this.bird = new Bird(BIRD_START_X, birdStartY);

        // Initialize pipe manager
        this.pipeManager = new PipeManager(
            canvas.width,
            canvas.height,
            GROUND_HEIGHT
        );

        // Initialize input handler
        this.inputHandler = new InputHandler(canvas);
        this.inputHandler.onJump(() => {
            if (this.state === GameState.Playing) {
                this.bird.jump();
            }
        });

        // Start game loop
        this.gameLoop();
    }

    /**
     * Main game loop using requestAnimationFrame
     */
    private gameLoop = (currentTime: number = performance.now()): void => {
        // Calculate delta time
        const deltaTime = currentTime - this.lastFrameTime;
        this.lastFrameTime = currentTime;

        if (this.state === GameState.Playing) {
            this.update(deltaTime);
        }

        this.render();
        this.animationFrameId = requestAnimationFrame(this.gameLoop);
    };

    /**
     * Update game state: bird, pipes, collisions, and scoring
     * @param deltaTime - Time elapsed since last frame (milliseconds)
     */
    private update(deltaTime: number): void {
        // Update bird physics
        this.bird.update(deltaTime);

        // Update pipes
        this.pipeManager.update(performance.now());

        // Check collisions
        if (this.checkCollisions()) {
            this.gameOver();
            return;
        }

        // Check scoring
        const scoreIncrement = this.pipeManager.checkScore(this.bird.getBounds());
        this.score += scoreIncrement;
    }

    /**
     * Check all collisions: pipes, ground, and ceiling
     * @returns true if collision detected
     */
    private checkCollisions(): boolean {
        const birdBounds = this.bird.getBounds();

        // Check ground collision
        if (birdBounds.y + birdBounds.height >= this.canvas.height - GROUND_HEIGHT) {
            return true;
        }

        // Check ceiling collision
        if (birdBounds.y <= CEILING_HEIGHT) {
            return true;
        }

        // Check pipe collisions
        if (this.pipeManager.checkCollision(birdBounds)) {
            return true;
        }

        return false;
    }

    /**
     * Handle game over state
     */
    private gameOver(): void {
        this.state = GameState.GameOver;
        this.showGameOverOverlay();
    }

    /**
     * Show game over overlay
     */
    private showGameOverOverlay(): void {
        const overlay = document.getElementById('gameOverOverlay');
        const finalScoreElement = document.getElementById('finalScore');
        
        if (overlay && finalScoreElement) {
            finalScoreElement.textContent = `Score: ${this.score}`;
            overlay.style.display = 'flex';
        }
    }

    /**
     * Render everything on the canvas
     */
    private render(): void {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Draw background (sky gradient is handled by CSS, but we can add clouds here)
        this.drawBackground();

        // Draw ground
        this.drawGround();

        // Draw pipes
        this.pipeManager.draw(this.ctx);

        // Draw bird
        this.bird.draw(this.ctx);

        // Draw UI (player name and score)
        this.drawUI();
    }

    /**
     * Draw background elements (optional: clouds, etc.)
     */
    private drawBackground(): void {
        // Background is handled by CSS gradient
        // Can add clouds or other decorative elements here
    }

    /**
     * Draw the ground
     */
    private drawGround(): void {
        const groundY = this.canvas.height - GROUND_HEIGHT;
        
        // Ground fill
        this.ctx.fillStyle = '#8B4513'; // Brown
        this.ctx.fillRect(0, groundY, this.canvas.width, GROUND_HEIGHT);

        // Ground grass line
        this.ctx.strokeStyle = '#228B22'; // Forest green
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.moveTo(0, groundY);
        this.ctx.lineTo(this.canvas.width, groundY);
        this.ctx.stroke();
    }

    /**
     * Draw UI elements: player name and score
     */
    private drawUI(): void {
        this.ctx.fillStyle = '#000';
        this.ctx.font = 'bold 24px Arial';
        this.ctx.textBaseline = 'top';

        // Draw player name (top-left)
        this.ctx.fillText(`Player: ${this.playerName}`, 10, 10);

        // Draw score (top-left, below name)
        this.ctx.fillText(`Score: ${this.score}`, 10, 40);
    }

    /**
     * Get current score
     */
    public getScore(): number {
        return this.score;
    }

    /**
     * Get current game state
     */
    public getState(): GameState {
        return this.state;
    }

    /**
     * Update canvas dimensions (for window resize)
     */
    public resize(newWidth: number, newHeight: number): void {
        // Update canvas dimensions
        this.canvas.width = newWidth;
        this.canvas.height = newHeight;

        // Update pipe manager dimensions
        this.pipeManager.updateDimensions(newWidth, newHeight, GROUND_HEIGHT);

        // Reset bird position if needed (or keep relative position)
        const birdStartY = newHeight * BIRD_START_Y_OFFSET;
        this.bird.reset(BIRD_START_X, birdStartY);
    }

    /**
     * Clean up game resources
     */
    public destroy(): void {
        if (this.animationFrameId !== null) {
            cancelAnimationFrame(this.animationFrameId);
        }
        this.inputHandler.destroy();
    }
}
