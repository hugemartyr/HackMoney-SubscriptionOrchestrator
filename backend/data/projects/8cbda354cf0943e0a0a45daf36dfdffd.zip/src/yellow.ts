import WebSocket from 'ws';
import { createAppSessionMessage } from '@erc7824/nitrolite';
import dotenv from 'dotenv';

dotenv.config();

/**
 * Initialize Yellow SDK connection to ClearNode.
 * This function establishes a WebSocket connection for state channel operations.
 */
export async function initYellow(): Promise<WebSocket> {
  const clearNodeUrl = process.env.CLEARNODE_WS_URL || 'wss://clearnet-sandbox.yellow.com/ws';
  
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(clearNodeUrl);

    ws.onopen = () => {
      console.log('[Yellow] Connected to ClearNode');
      resolve(ws);
    };

    ws.onerror = (error) => {
      console.error('[Yellow] WebSocket connection error:', error);
      reject(error);
    };

    ws.onmessage = (event) => {
      console.log('[Yellow] Message received:', event.data);
    };

    ws.onclose = () => {
      console.log('[Yellow] Disconnected from ClearNode');
    };
  });
}

export default initYellow;
