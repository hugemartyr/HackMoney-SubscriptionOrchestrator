import { GRAVITY, JUMP_STRENGTH, BIRD_SIZE, MAX_ROTATION_UP, MAX_ROTATION_DOWN, ROTATION_SPEED } from './constants';
import { Rectangle } from './types';

/**
 * Bird - Handles bird physics, rendering, and collision bounds
 */
export class Bird {
    public x: number;
    public y: number;
    public width: number;
    public height: number;
    public velocity: number;
    public rotation: number;

    constructor(startX: number, startY: number) {
        this.x = startX;
        this.y = startY;
        this.width = BIRD_SIZE;
        this.height = BIRD_SIZE;
        this.velocity = 0;
        this.rotation = 0;
    }

    /**
     * Update bird physics: apply gravity, update position, and calculate rotation
     * @param deltaTime - Time elapsed since last frame (in milliseconds)
     */
    public update(deltaTime: number): void {
        // Apply gravity (convert deltaTime to frame-based calculation)
        // For consistent physics, we use a frame multiplier
        const frameMultiplier = deltaTime / 16.67; // Normalize to ~60fps
        this.velocity += GRAVITY * frameMultiplier;
        
        // Update position
        this.y += this.velocity * frameMultiplier;

        // Calculate rotation based on velocity
        // Positive velocity (falling) = rotate down, negative (rising) = rotate up
        let targetRotation = 0;
        if (this.velocity > 0) {
            // Falling: rotate down proportionally to velocity
            targetRotation = Math.min(MAX_ROTATION_DOWN, this.velocity * 5);
        } else {
            // Rising: rotate up
            targetRotation = MAX_ROTATION_UP;
        }

        // Smoothly interpolate rotation
        if (this.rotation < targetRotation) {
            this.rotation = Math.min(targetRotation, this.rotation + ROTATION_SPEED * frameMultiplier);
        } else if (this.rotation > targetRotation) {
            this.rotation = Math.max(targetRotation, this.rotation - ROTATION_SPEED * frameMultiplier);
        }
    }

    /**
     * Make the bird jump by applying upward velocity
     */
    public jump(): void {
        this.velocity = JUMP_STRENGTH;
    }

    /**
     * Get Axis-Aligned Bounding Box for collision detection
     */
    public getBounds(): Rectangle {
        return {
            x: this.x,
            y: this.y,
            width: this.width,
            height: this.height
        };
    }

    /**
     * Draw the bird on the canvas with rotation
     * @param ctx - Canvas 2D rendering context
     */
    public draw(ctx: CanvasRenderingContext2D): void {
        ctx.save();

        // Move to bird center for rotation
        const centerX = this.x + this.width / 2;
        const centerY = this.y + this.height / 2;

        // Translate to center, rotate, then translate back
        ctx.translate(centerX, centerY);
        ctx.rotate((this.rotation * Math.PI) / 180);
        ctx.translate(-centerX, -centerY);

        // Draw bird body (simple rectangle for now, can be replaced with sprite)
        ctx.fillStyle = '#FFD700'; // Gold color
        ctx.fillRect(this.x, this.y, this.width, this.height);

        // Draw bird eye
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(this.x + this.width * 0.7, this.y + this.height * 0.3, 4, 0, Math.PI * 2);
        ctx.fill();

        // Draw bird beak
        ctx.fillStyle = '#FF8C00';
        ctx.beginPath();
        ctx.moveTo(this.x + this.width, this.y + this.height * 0.4);
        ctx.lineTo(this.x + this.width + 8, this.y + this.height * 0.5);
        ctx.lineTo(this.x + this.width, this.y + this.height * 0.6);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
    }

    /**
     * Reset bird to initial state
     */
    public reset(startX: number, startY: number): void {
        this.x = startX;
        this.y = startY;
        this.velocity = 0;
        this.rotation = 0;
    }
}
