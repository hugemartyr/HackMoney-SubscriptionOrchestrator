/**
 * Game physics and configuration constants
 */

// Bird physics
export const GRAVITY = 0.5; // pixels per frame²
export const JUMP_STRENGTH = -10; // negative for upward movement
export const BIRD_SIZE = 40; // width and height of the bird

// Bird rotation limits (in degrees)
export const MAX_ROTATION_UP = -25; // Maximum upward rotation
export const MAX_ROTATION_DOWN = 90; // Maximum downward rotation
export const ROTATION_SPEED = 3; // Degrees per frame

// Pipe settings
export const PIPE_SPEED = 3; // pixels per frame
export const PIPE_SPAWN_INTERVAL = 2000; // milliseconds
export const PIPE_WIDTH = 80;
export const PIPE_GAP = 200; // gap between top and bottom pipes
export const PIPE_MIN_HEIGHT = 50; // minimum height for top/bottom pipe sections

// Ground and ceiling collision boundaries
export const GROUND_HEIGHT = 50; // height of ground from bottom
export const CEILING_HEIGHT = 0; // top boundary

// Initial bird position
export const BIRD_START_X = 100; // horizontal starting position
export const BIRD_START_Y_OFFSET = 0.4; // 40% from top of screen
