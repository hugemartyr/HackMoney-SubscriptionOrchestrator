
import {
  createAuthRequestMessage,
  createEIP712AuthMessageSigner,
  createAuthVerifyMessage,
  RPCMethod,
  RPCResponse
} from "@erc7824/nitrolite";

import { Client } from "yellow-ts";
import { createWalletClient, http, WalletClient } from "viem";
import { mnemonicToAccount } from "viem/accounts";

import {
  AUTH_SCOPE,
  APP_NAME,
  SESSION_DURATION,
  DEFAULT_ALLOWANCES,
  YELLOW_CHAIN
} from "./config";

import { generateSessionKey, SessionKey } from "./utils";

export function createWalletFromMnemonic(seed: string): WalletClient {
  return createWalletClient({
    account: mnemonicToAccount(seed),
    chain: YELLOW_CHAIN,
    transport: http(),
  });
}

export async function authenticateWallet(
  client: Client,
  walletClient: WalletClient
): Promise<SessionKey> {

  const sessionKey = generateSessionKey();
  const expires = String(Math.floor(Date.now() / 1000) + SESSION_DURATION);

  const authMessage = await createAuthRequestMessage({
    address: walletClient.account?.address!,
    session_key: sessionKey.address,
    application: APP_NAME,
    allowances: DEFAULT_ALLOWANCES,
    expires_at: BigInt(expires),
    scope: AUTH_SCOPE,
  });

  client.listen(async (message: RPCResponse) => {
    if (message.method === RPCMethod.AuthChallenge) {
      const authParams = {
        scope: AUTH_SCOPE,
        application: walletClient.account?.address!,
        participant: sessionKey.address,
        expire: expires,
        allowances: DEFAULT_ALLOWANCES,
        session_key: sessionKey.address,
        expires_at: BigInt(expires),
      };

      const signer = createEIP712AuthMessageSigner(
        walletClient,
        authParams,
        { name: APP_NAME }
      );

      const verifyMsg = await createAuthVerifyMessage(
        signer,
        message
      );

      await client.sendMessage(verifyMsg);
    }
  });

  await client.sendMessage(authMessage);

  return sessionKey;
}
