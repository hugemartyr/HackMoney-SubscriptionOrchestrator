
import { base } from "viem/chains";

export const YELLOW_WS =
  process.env.YELLOW_WS ??
  "wss://clearnet-sandbox.yellow.com/ws";

export const YELLOW_CHAIN = base;

export const AUTH_SCOPE =
  process.env.YELLOW_SCOPE ?? "test.app";

export const APP_NAME =
  process.env.YELLOW_APP_NAME ?? "Test app";

export const SESSION_DURATION = 3600;

export const DEFAULT_ALLOWANCES = [
  {
    asset: "usdc",
    amount: "1",
  },
];
