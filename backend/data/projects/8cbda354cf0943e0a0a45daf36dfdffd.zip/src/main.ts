import { Game } from './Game';

/**
 * Main entry point - Initializes canvas, handles overlay events, and manages game lifecycle
 */

let game: Game | null = null;
let resizeTimeout: number | null = null;

/**
 * Initialize the game canvas with full window dimensions
 */
function initializeCanvas(): HTMLCanvasElement {
    const canvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
    if (!canvas) {
        throw new Error('Canvas element not found');
    }

    // Set canvas to full window dimensions
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    return canvas;
}

/**
 * Handle window resize events with debouncing
 * 
 * Resize Logic Explanation:
 * - We use a debounced resize handler to avoid excessive resize operations
 * - When the window is resized, we wait 100ms before actually resizing
 * - This prevents performance issues from rapid resize events
 * - The canvas dimensions are updated to match the new window size
 * - If a game is running, we update its dimensions to maintain proper rendering
 * - The canvas context is preserved during resize (no need to recreate it)
 */
function setupResizeListener(canvas: HTMLCanvasElement): void {
    window.addEventListener('resize', () => {
        // Debounce resize events to avoid excessive updates
        if (resizeTimeout !== null) {
            clearTimeout(resizeTimeout);
        }

        resizeTimeout = window.setTimeout(() => {
            // Update canvas dimensions to match new window size
            const newWidth = window.innerWidth;
            const newHeight = window.innerHeight;

            canvas.width = newWidth;
            canvas.height = newHeight;

            // If game is running, update its dimensions
            if (game) {
                game.resize(newWidth, newHeight);
            }

            resizeTimeout = null;
        }, 100); // Wait 100ms after last resize event
    });
}

/**
 * Handle start button click - hide overlay and start game
 */
function setupStartButton(canvas: HTMLCanvasElement): void {
    const startButton = document.getElementById('startButton');
    const startOverlay = document.getElementById('startOverlay');
    const playerNameInput = document.getElementById('playerName') as HTMLInputElement;

    if (!startButton || !startOverlay || !playerNameInput) {
        throw new Error('Required overlay elements not found');
    }

    startButton.addEventListener('click', () => {
        const playerName = playerNameInput.value.trim();

        // Validate player name
        if (playerName === '') {
            alert('Please enter your name to start the game!');
            return;
        }

        // Hide start overlay
        startOverlay.style.display = 'none';

        // Clean up previous game if exists
        if (game) {
            game.destroy();
        }

        // Initialize and start new game
        game = new Game(canvas, playerName);
    });

    // Allow Enter key to start game
    playerNameInput.addEventListener('keydown', (event: KeyboardEvent) => {
        if (event.key === 'Enter') {
            startButton.click();
        }
    });
}

/**
 * Handle restart button click - reset and start new game
 */
function setupRestartButton(canvas: HTMLCanvasElement): void {
    const restartButton = document.getElementById('restartButton');
    const gameOverOverlay = document.getElementById('gameOverOverlay');
    const startOverlay = document.getElementById('startOverlay');
    const playerNameInput = document.getElementById('playerName') as HTMLInputElement;

    if (!restartButton || !gameOverOverlay || !startOverlay || !playerNameInput) {
        throw new Error('Required overlay elements not found');
    }

    restartButton.addEventListener('click', () => {
        // Hide game over overlay
        gameOverOverlay.style.display = 'none';

        // Clean up previous game
        if (game) {
            game.destroy();
            game = null;
        }

        // Show start overlay again
        startOverlay.style.display = 'flex';
        playerNameInput.focus();
    });
}

/**
 * Main initialization function
 */
function main(): void {
    try {
        // Initialize canvas
        const canvas = initializeCanvas();

        // Set up resize listener
        setupResizeListener(canvas);

        // Set up start button
        setupStartButton(canvas);

        // Set up restart button
        setupRestartButton(canvas);

        // Focus on player name input when page loads
        const playerNameInput = document.getElementById('playerName') as HTMLInputElement;
        if (playerNameInput) {
            playerNameInput.focus();
        }
    } catch (error) {
        console.error('Failed to initialize game:', error);
        alert('Failed to initialize game. Please refresh the page.');
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', main);
} else {
    main();
}
