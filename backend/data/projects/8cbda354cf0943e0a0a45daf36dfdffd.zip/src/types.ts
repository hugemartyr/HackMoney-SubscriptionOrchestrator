/**
 * Rectangle interface for AABB collision detection
 */
export interface Rectangle {
    x: number;
    y: number;
    width: number;
    height: number;
}

/**
 * Pipe pair structure
 */
export interface Pipe {
    x: number;
    topHeight: number;
    bottomY: number;
    width: number;
    gap: number;
    passed: boolean;
}

/**
 * Game state enumeration
 */
export enum GameState {
    Start = 'start',
    Playing = 'playing',
    GameOver = 'gameover'
}
