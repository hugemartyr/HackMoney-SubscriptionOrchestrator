import { Pipe, Rectangle } from './types';
import { PIPE_SPEED, PIPE_SPAWN_INTERVAL, PIPE_WIDTH, PIPE_GAP, PIPE_MIN_HEIGHT } from './constants';

/**
 * PipeManager - Handles pipe generation, movement, recycling, collision, and scoring
 */
export class PipeManager {
    private pipes: Pipe[] = [];
    private spawnInterval: number;
    private lastSpawnTime: number;
    private canvasWidth: number;
    private canvasHeight: number;
    private groundHeight: number;

    constructor(canvasWidth: number, canvasHeight: number, groundHeight: number) {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.groundHeight = groundHeight;
        this.spawnInterval = PIPE_SPAWN_INTERVAL;
        this.lastSpawnTime = 0;
    }

    /**
     * Update pipes: move them left, spawn new ones, and remove off-screen pipes
     * @param currentTime - Current timestamp in milliseconds
     */
    public update(currentTime: number): void {
        // Move all pipes left
        for (const pipe of this.pipes) {
            pipe.x -= PIPE_SPEED;
        }

        // Spawn new pipe if enough time has passed
        if (currentTime - this.lastSpawnTime >= this.spawnInterval) {
            this.spawnPipe();
            this.lastSpawnTime = currentTime;
        }

        // Remove pipes that have gone off-screen (recycling)
        this.pipes = this.pipes.filter(pipe => pipe.x + pipe.width > -50);
    }

    /**
     * Spawn a new pipe pair with random gap position
     */
    private spawnPipe(): void {
        // Calculate available space (canvas height minus ground and minimum pipe heights)
        const availableHeight = this.canvasHeight - this.groundHeight - (PIPE_MIN_HEIGHT * 2);
        
        // Random gap center position (ensuring minimum heights for top and bottom)
        const gapCenter = PIPE_MIN_HEIGHT + Math.random() * (availableHeight - PIPE_GAP - PIPE_MIN_HEIGHT);
        
        // Calculate top pipe height and bottom pipe position
        const topHeight = gapCenter - PIPE_GAP / 2;
        const bottomY = gapCenter + PIPE_GAP / 2;

        const pipe: Pipe = {
            x: this.canvasWidth,
            topHeight: Math.max(PIPE_MIN_HEIGHT, topHeight),
            bottomY: bottomY,
            width: PIPE_WIDTH,
            gap: PIPE_GAP,
            passed: false
        };

        this.pipes.push(pipe);
    }

    /**
     * Draw all pipes on the canvas
     * @param ctx - Canvas 2D rendering context
     */
    public draw(ctx: CanvasRenderingContext2D): void {
        ctx.fillStyle = '#228B22'; // Forest green

        for (const pipe of this.pipes) {
            // Draw top pipe
            ctx.fillRect(pipe.x, 0, pipe.width, pipe.topHeight);

            // Draw bottom pipe
            const bottomHeight = this.canvasHeight - this.groundHeight - pipe.bottomY;
            ctx.fillRect(pipe.x, pipe.bottomY, pipe.width, bottomHeight);

            // Draw pipe caps (decorative)
            ctx.fillStyle = '#32CD32'; // Lime green for caps
            const capHeight = 20;
            
            // Top cap
            ctx.fillRect(pipe.x - 5, pipe.topHeight - capHeight, pipe.width + 10, capHeight);
            
            // Bottom cap
            ctx.fillRect(pipe.x - 5, pipe.bottomY, pipe.width + 10, capHeight);
            
            ctx.fillStyle = '#228B22'; // Reset to main color
        }
    }

    /**
     * Check collision between bird and all pipes using AABB
     * @param birdBounds - Bird's bounding rectangle
     * @returns true if collision detected
     */
    public checkCollision(birdBounds: Rectangle): boolean {
        for (const pipe of this.pipes) {
            // Top pipe collision
            const topPipe: Rectangle = {
                x: pipe.x,
                y: 0,
                width: pipe.width,
                height: pipe.topHeight
            };

            if (this.checkAABB(birdBounds, topPipe)) {
                return true;
            }

            // Bottom pipe collision
            const bottomHeight = this.canvasHeight - this.groundHeight - pipe.bottomY;
            const bottomPipe: Rectangle = {
                x: pipe.x,
                y: pipe.bottomY,
                width: pipe.width,
                height: bottomHeight
            };

            if (this.checkAABB(birdBounds, bottomPipe)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Axis-Aligned Bounding Box collision detection
     * @param rect1 - First rectangle
     * @param rect2 - Second rectangle
     * @returns true if rectangles overlap
     */
    private checkAABB(rect1: Rectangle, rect2: Rectangle): boolean {
        return (
            rect1.x < rect2.x + rect2.width &&
            rect1.x + rect1.width > rect2.x &&
            rect1.y < rect2.y + rect2.height &&
            rect1.y + rect1.height > rect2.y
        );
    }

    /**
     * Check if bird has passed pipes and update score
     * @param birdBounds - Bird's bounding rectangle
     * @returns number of newly passed pipes (for score increment)
     */
    public checkScore(birdBounds: Rectangle): number {
        let scoreIncrement = 0;

        for (const pipe of this.pipes) {
            // Check if bird has passed the pipe (bird's right edge > pipe's right edge)
            if (!pipe.passed && birdBounds.x > pipe.x + pipe.width) {
                pipe.passed = true;
                scoreIncrement++;
            }
        }

        return scoreIncrement;
    }

    /**
     * Reset pipe manager (clear all pipes)
     */
    public reset(): void {
        this.pipes = [];
        this.lastSpawnTime = 0;
    }

    /**
     * Update canvas dimensions (for window resize)
     */
    public updateDimensions(canvasWidth: number, canvasHeight: number, groundHeight: number): void {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        this.groundHeight = groundHeight;
    }

    /**
     * Get all pipes (for debugging or external use)
     */
    public getPipes(): Pipe[] {
        return this.pipes;
    }
}
