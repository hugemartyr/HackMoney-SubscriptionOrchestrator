/**
 * InputHandler - Manages user input events (mouse clicks and keyboard)
 */
export class InputHandler {
    private jumpCallback: (() => void) | null = null;
    private canvas: HTMLCanvasElement;

    constructor(canvas: HTMLCanvasElement) {
        this.canvas = canvas;
        this.setupEventListeners();
    }

    /**
     * Set up event listeners for mouse clicks and spacebar presses
     */
    private setupEventListeners(): void {
        // Mouse click on canvas
        this.canvas.addEventListener('click', () => {
            this.triggerJump();
        });

        // Spacebar key press
        window.addEventListener('keydown', (event: KeyboardEvent) => {
            if (event.code === 'Space' || event.key === ' ') {
                event.preventDefault(); // Prevent page scroll
                this.triggerJump();
            }
        });
    }

    /**
     * Register callback function to be called when jump is triggered
     */
    public onJump(callback: () => void): void {
        this.jumpCallback = callback;
    }

    /**
     * Trigger the jump action by calling the registered callback
     */
    private triggerJump(): void {
        if (this.jumpCallback) {
            this.jumpCallback();
        }
    }

    /**
     * Clean up event listeners (for potential future use)
     */
    public destroy(): void {
        // Event listeners will be cleaned up automatically when canvas is removed
        // But we can explicitly remove them if needed
        this.jumpCallback = null;
    }
}
